//
//  LocalizationDictionary.swift
//  idap_study_task10
//
//  Created by Filipp Kosenko on 07.03.2023.
//

import Foundation

struct DashboardLocalizationDictionary {
    
    static var localization = [Int : String]()
    
    init() {
        
    }
    
}
