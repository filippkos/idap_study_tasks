//
//  DashboardCollectionViewModel.swift
//  idap_study_task10
//
//  Created by Filipp Kosenko on 08.03.2023.
//

import Foundation

struct DashboardCollectionViewModel {
    
    
}
