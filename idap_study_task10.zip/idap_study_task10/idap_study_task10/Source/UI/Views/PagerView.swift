//
//  PaigerView.swift
//  idap_study_task10
//
//  Created by Filipp Kosenko on 04.03.2023.
//

import UIKit
import SnapKit

class PagerView: UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate {

    // MARK: -
    // MARK: Variables
    
    let numberOfPages: Int = 3
    var arrayOfViews: [UIView] = []
    let layout = UICollectionViewFlowLayout()
    
    init() {
        super.init(frame: CGRect(), collectionViewLayout: layout)
        self.prepareLayout()
        self.register(cellClass: UICollectionViewCell.self)
        self.dataSource = self
        self.delegate = self

        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.prepareLayout()
        self.register(cellClass: UICollectionViewCell.self)
        self.dataSource = self
        self.backgroundColor = .red
        self.setup()
    }
    
    // MARK: -
    // MARK: Private
    
    private func prepareLayout() {
        let itemWidth = self.frame.size.width
        let itemHeight = self.frame.size.height
        self.layout.scrollDirection = .horizontal
        self.layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
        self.layout.minimumLineSpacing = 2
    }
    
    private func setup() {
        self.prepareViews()
    }
    
    private func prepareViews() {
        for _ in 0...self.numberOfPages {
            let view = UIView()
            view.frame.size = CGSize(width: 20, height: 20)
            view.backgroundColor = .blue
            self.arrayOfViews.append(view)
        }
    }
    
    // MARK: -
    // MARK: DataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.numberOfPages
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = dequeueReusableCell(cellClass: UICollectionViewCell.self, indexPath: indexPath)
        let view = self.arrayOfViews[indexPath.row]
        cell.addSubview(view)
 
        return cell
    }
}
