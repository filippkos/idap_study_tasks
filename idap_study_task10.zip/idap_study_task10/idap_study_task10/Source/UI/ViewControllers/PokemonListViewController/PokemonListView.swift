//
//  PokemonListView.swift
//  idap_study_task10
//
//  Created by Filipp Kosenko on 02.03.2023.
//

import UIKit

final class PokemonListView: BaseView {
    
    // MARK: -
    // MARK: Outlets
    
    @IBOutlet internal var tableView: UITableView?
}

